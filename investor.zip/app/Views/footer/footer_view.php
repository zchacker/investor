<section class="footer1 cid-sFMJCU1DGd" once="footers" id="footer1-6">

    
    
    <div class="container">
        <div class="row mbr-white">
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7">
                    <strong>تعرف علينا</strong></h5>
                <ul class="list mbr-fonts-style display-4">
                    <li class="mbr-text item-wrap">من نحن</li>
                    <li class="mbr-text item-wrap">رؤيتنا</li>
                    <li class="mbr-text item-wrap">سياسة الموقع</li>
                    <li class="mbr-text item-wrap">سياسة الخصوصية</li>
                </ul>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7">
                    <strong>روابط مهمة</strong></h5>
                <ul class="list mbr-fonts-style display-4">

                    <li class="mbr-text item-wrap">كيف تضيف المشروع</li>
                    <li class="mbr-text item-wrap">كيف تطلب الاستثمار في مشروع</li>
                    <li class="mbr-text item-wrap">إرشادات</li>
                </ul>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7">
                    <strong>اتصل بنا</strong></h5>
                <ul class="list mbr-fonts-style display-4">
                    <li class="mbr-text item-wrap">رقم الهاتف: +966536301031</li><li class="mbr-text item-wrap">البريد الالكتروني: ahmed@gmail.com</li><li class="mbr-text item-wrap">عنوان المكتب:</li><li class="mbr-text item-wrap">جدة , المملكة العربية السعودية</li>
                </ul>
            </div>
            <div class="col-12 col-md-6 col-lg-3">
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-2 display-7">
                    <strong>إيرنو</strong></h5>
                <p class="mbr-text mbr-fonts-style mb-4 display-4">
                    هي منصة تعمل في السعودية لمساعدة أصحاب المشاريع في الحصول على مستثمرين لمساعدتهم في نمو المشروع مقابل الشراكة بنسبة من المشروع</p>
                <h5 class="mbr-section-subtitle mbr-fonts-style mb-3 display-7">
                    <strong>وسائل التواصل</strong></h5>
                <div class="social-row display-7">
                    <div class="soc-item">
                        <a href="https://twitter.com/mobirise" target="_blank">
                            <span class="mbr-iconfont socicon socicon-facebook"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="https://twitter.com/mobirise" target="_blank">
                            <span class="mbr-iconfont socicon socicon-twitter"></span>
                        </a>
                    </div>
                    <div class="soc-item">
                        <a href="https://twitter.com/mobirise" target="_blank">
                            <span class="mbr-iconfont socicon socicon-instagram"></span>
                        </a>
                    </div>
                    
                </div>
            </div>
            
        </div>
    </div>
</section><section style="background-color: #fff; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', 'Roboto', 'Helvetica Neue', Arial, sans-serif; color:#aaa; font-size:12px; padding: 0; align-items: center; display: flex;"><a href="https://mobirise.site/p" style="flex: 1 1; height: 3rem; padding-left: 1rem;"></a><p style="flex: 0 0 auto; margin:0; padding-right:1rem;">Created with Mobirise - <a href="https://mobirise.site/k" style="color:#aaa;">Check it</a></p></section><script src="assets/web/assets/jquery/jquery.min.js"></script>  <script src="assets/popper/popper.min.js"></script>  <script src="assets/tether/tether.min.js"></script>  <script src="assets/bootstrap/js/bootstrap.min.js"></script>  <script src="assets/smoothscroll/smooth-scroll.js"></script>  <script src="assets/dropdown/js/nav-dropdown.js"></script>  <script src="assets/dropdown/js/navbar-dropdown.js"></script>  <script src="assets/touchswipe/jquery.touch-swipe.min.js"></script>  <script src="assets/sociallikes/social-likes.js"></script>  <script src="assets/theme/js/script.js"></script>  
  
  
</body>
</html>